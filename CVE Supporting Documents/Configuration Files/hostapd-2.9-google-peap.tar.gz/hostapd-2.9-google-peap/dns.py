# python dns.py -i wlan0 -o eth0

from argparse import ArgumentParser
import os

def set_configs():
    parser = ArgumentParser()
    parser.add_argument('-o',
                  dest='output',
                  type=str,
                  help='the interface of the output')

    parser.add_argument('-i',
                  dest='iface',
                  default='wlan0',
                  type=str,
                  help='the interface of the AP')

    args = parser.parse_args()

    return {
        'iface' : args.iface,
        'output': args.output,
    }

def dnsmasq(iface):
    os.system("systemctl stop dnsmasq")
    os.system("killall dnsmasq > /dev/null 2>&1")
    os.system("ifconfig " + iface + " 172.5.10.1/24")
    os.system("echo 'dhcp-range=172.5.10.100,172.5.10.250,12h' > dnsmasq.conf")
    os.system("echo 'interface=" + iface +"' >> dnsmasq.conf")
    os.system("ifconfig " + iface + " up")
    os.system("dnsmasq -C dnsmasq.conf -l dnsmasq.leases")

def iptables(output):
    os.system("iptables -F")
    os.system("iptables -t nat -F")

    if output:
        os.system("echo 1 > /proc/sys/net/ipv4/ip_forward")
        os.system("ifconfig " + output + " up")
        os.system("dhclient " + output + " > /dev/null 2>&1")
        os.system("iptables -t nat -A POSTROUTING -o " + output + " -j MASQUERADE")

def hostapd(iface):
    os.system("ifconfig " + iface + " 172.5.10.1/24")

if __name__ == '__main__':
    confs = set_configs()
    iface = confs["iface"]
    output = confs["output"]

    #DNS and DHCP server
    dnsmasq(iface)
    #iptables
    iptables(output)
    #hostapd config
    hostapd(iface)
