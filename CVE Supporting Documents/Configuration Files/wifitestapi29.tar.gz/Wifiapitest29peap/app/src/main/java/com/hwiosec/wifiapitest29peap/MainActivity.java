package com.hwiosec.wifiapitest29peap;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.net.wifi.WifiEnterpriseConfig;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.hwiosec.wifimanagement.WifiConfigUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private Button mTestWiFiButton;
    private Uri mCaCertUri;
    String ssid = "Hacked Inc";
    String identity = "test";
    String password = "123456";
    public final static String TAG = "TestPeap";
    private X509Certificate parseX509Certificate(Uri uri) {
        try {
            CertificateFactory factory = CertificateFactory.getInstance("X.509");
            InputStream inputStream = getApplicationContext().getContentResolver().openInputStream(uri);
            return (X509Certificate) factory.generateCertificate(inputStream);
        } catch ( CertificateException | FileNotFoundException ex) {
            Log.e(TAG, "parseX509Certificate: ", ex);
            return null;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTestWiFiButton = findViewById(R.id.test_button);
        mCaCertUri = Uri.fromFile(new File("/data/local/tmp/ca.der"));
        mTestWiFiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                X509Certificate caCert = parseX509Certificate(mCaCertUri);



                boolean success = saveWifiConfiguration(ssid, caCert, identity, password);

            }
        });

    }

    private boolean saveWifiConfiguration(String ssid, X509Certificate caCert,
                                          String identity, String password)  {


       WifiEnterpriseConfig wc = new WifiEnterpriseConfig();
        wc.setEapMethod(WifiEnterpriseConfig.Eap.PEAP);
        wc.setPhase2Method(WifiEnterpriseConfig.Phase2.MSCHAPV2);
        wc.setIdentity(identity);
        wc.setCaCertificate(caCert);
        wc.setPassword(password);



        WifiNetworkSuggestion wifiNetworkSuggestion = new WifiNetworkSuggestion.Builder()
                .setPriority(322)
                .setSsid(ssid)
                .setIsMetered(true)
                .setWpa2EnterpriseConfig(wc)

                .build();



        ArrayList<WifiNetworkSuggestion> suggestionsList = new ArrayList<WifiNetworkSuggestion>();
        suggestionsList.add(wifiNetworkSuggestion);





        boolean added =  WifiConfigUtil.addWifiNetworkSuggestion(getApplicationContext(), suggestionsList);

//        WifiNetworkSpecifier wifiNetworkSpecifier = new WifiNetworkSpecifier.Builder().setSsid("HackedInc")
//                .setWpa2EnterpriseConfig(enterpriseConfig)
//                .build();
//        boolean connected = WifiConfigUtil.connectToSpecificNetwork(getApplicationContext(), wifiNetworkSpecifier);

        return false;

    }
}
